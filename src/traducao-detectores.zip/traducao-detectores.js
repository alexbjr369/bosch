setInterval(() => {
  const change = document.querySelector('.step-2 .init-quiz p');
  if (change) change.innerHTML = 'Marque <strong>sólo una</strong> de las opciones siguientes:';
}, 100);
